import java.util.Scanner;
import java.lang.Math;
import java.util.Random;

public class Application {
	
	public static void Fight() {
		int[] characterHP = {170, 120, 180, 300};
		int[] characterATK = {70, 50, 80, 100};
		int[] characterDEF = {15, 10, 20, 30};
		int[] characterCP = {75, 50, 80, 100};
		String[] characterName = {"Naruto", " Sasuke", "Gaara", "Kakashi"};
		int hp = 0;
		int atk = 0;
		int def = 0;
		int enATK = 70;
		int enHP = 170;
		int enDEF = 12;
		int cp = 0;
		int enCP = 50;
		int streak = 0;
		boolean unlocked = false;
		String name = "";
		while(true) {
			Scanner input  = new Scanner(System.in);
			System.out.println("1. NARUTO (HP)");
			System.out.println("2. SASUKE (ATK)");
			System.out.println("3. GAARA (DEF)");
			if(unlocked == true) {
				System.out.println("4. KAKASHI (ALL)");
			}else {
				System.out.print("4. [LOCKED] ");
				System.out.print(3 - streak);
				System.out.println(" more streaks to go to unlock special character.");
			}
			System.out.println("Select character [1-4] >> ");
			int inpNum = input.nextInt();
			if(inpNum == 4 && unlocked == false) {
				System.out.println("You haven't unlocked that character.");
				Scanner ph4 = new Scanner(System.in);
				System.out.print("Enter >> ");
				String inp4 = ph4.nextLine();
				enHP = 150;
				enCP = 50;
			}
			else if(inpNum <= 3 && unlocked == false) {
				for(int i = 0; i < 3; ++i) {
					hp = characterHP[inpNum - 1];
					atk = characterATK[inpNum - 1];
					def = characterDEF[inpNum - 1];
					name = characterName[inpNum - 1];
					cp = characterCP[inpNum - 1];
					enHP = 150;
					enCP = 50;
				}
			}else {
				for(int i = 0; i < 4; ++i) {
					hp = characterHP[inpNum - 1];
					atk = characterATK[inpNum - 1];
					def = characterDEF[inpNum - 1];
					name = characterName[inpNum - 1];
					cp = characterCP[inpNum - 1];
					enHP = 150;
					enCP = 50;
				}
			}
			while(true) {
				int defense = 1;
				System.out.println(name + "\n" + "=============\nHP: " + hp);
				System.out.println("\nNeiji" + "\n" + "============\nHP: " + enHP);
				System.out.print("\nACT:\n[1] Attack\n[2] Def\n[3] Special Power (15-25 CP)\n[4] Quit\n\nEnter >> ");
				Scanner input2 = new Scanner(System.in);
				String act = input2.nextLine();
				double dmg = (int)(Math.random() * ((atk) - (atk - 25) + 1)) + (atk - 25);
				double enDmg = (int)(Math.random() * ((enATK) - (enATK - 25) + 1)) + (enATK - 25);
				double enAct = (int)(Math.random() * (3 - 1) + 1) + 1;
				if(act.equals("1")) {
					enHP -= (dmg - enDEF);
				}
				else if(act.equals("2")) {
					defense = 2;
				}
				else if(act.equals("3") && cp > 25) {
					enHP -= (dmg - enDEF) * 2;
					double consump = (int)(Math.random() * (25 - 15) + 1) + 15;
					cp -= consump;
				}else if(act.equals("0")) {
					break;
				}
				
				if(enAct == 1 && enCP > 15) {
					hp -= (enDmg - def) * 2;
					enCP -= 15;
				}
				else {
					hp -= (enDmg - def);
				}
				
				System.out.println("\nYou did " + dmg + " damage to Neiji!");
				System.out.println("Neiji did " + enDmg + " to you!");
				Scanner ph = new Scanner(System.in);
				System.out.print("Enter >> ");
				String in = ph.nextLine();
				
				if(hp <= 0) {
					Scanner ph2 = new Scanner(System.in);
					System.out.println("YOU LOSE!");
					streak = 0;
					String in2 = ph.nextLine();
					break;
				}
				if(enHP <= 0) {
					Scanner ph3 = new Scanner(System.in);
					System.out.println("YOU WIN!");
					String in3 = ph.nextLine();
					streak++;
					if(streak >= 3) {
						unlocked = true;
					}
					break;
				}
				
					
			}
			
		}
	}
	
	public static void Menu() {
		Scanner input = new Scanner(System.in);
		System.out.print("MAIN MENU\n\n[1] PLAY\n[2] HELP\n\nEnter >> ");
		String str = input.nextLine();
		if(str.equals("1")) {
			Fight();
		}
		
	}
	public static void main (String[] args) {
		Menu();
	}
}
